package com.example.btth402

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    lateinit var editTextName: EditText
    lateinit var editTextPhone: EditText
    lateinit var buttonAdd: Button
    lateinit var buttonUpdate: Button
    lateinit var buttonDelete: Button
    lateinit var buttonShow: Button
    lateinit var textViewDisplay: TextView
    lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextName = findViewById(R.id.editTextName)
        editTextPhone = findViewById(R.id.editTextPhone)
        buttonAdd = findViewById(R.id.buttonAdd)
        buttonUpdate = findViewById(R.id.buttonUpdate)
        buttonDelete = findViewById(R.id.buttonDelete)
        buttonShow = findViewById(R.id.buttonShow)
        textViewDisplay = findViewById(R.id.textViewDisplay)
        dbHelper = DatabaseHelper(this)

        buttonAdd.setOnClickListener {
            dbHelper.addContact(editTextName.text.toString(), editTextPhone.text.toString())
            Toast.makeText(this, "Đã thêm liên hệ!", Toast.LENGTH_SHORT).show()
        }

        buttonUpdate.setOnClickListener {
            dbHelper.updateContact(editTextName.text.toString(), editTextPhone.text.toString())
            Toast.makeText(this, "Đã sửa liên hệ!", Toast.LENGTH_SHORT).show()
        }

        buttonDelete.setOnClickListener {
            dbHelper.deleteContact(editTextName.text.toString())
            Toast.makeText(this, "Đã xóa liên hệ!", Toast.LENGTH_SHORT).show()
        }

        buttonShow.setOnClickListener {
            val contacts = dbHelper.getAllContacts()
            textViewDisplay.text = contacts.joinToString("\n") { "${it.first}: ${it.second}" }
        }
    }
}