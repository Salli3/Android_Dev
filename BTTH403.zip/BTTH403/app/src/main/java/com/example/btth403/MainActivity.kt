package com.example.btth403

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class MainActivity : Activity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var buttonSignUp: Button
    private lateinit var buttonSignIn: Button
    private lateinit var buttonShowData: Button
    private lateinit var textViewData: TextView

    companion object {
        private const val TAG = "MainActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = Firebase.auth
        database = Firebase.database.reference

        editTextEmail = findViewById(R.id.editTextEmail)
        editTextPassword = findViewById(R.id.editTextPassword)
        buttonSignUp = findViewById(R.id.buttonSignUp)
        buttonSignIn = findViewById(R.id.buttonSignIn)
        buttonShowData = findViewById(R.id.buttonShowData)
        textViewData = findViewById(R.id.textViewData)

        buttonSignUp.setOnClickListener { signUpUser() }
        buttonSignIn.setOnClickListener { signInUser() }
        buttonShowData.setOnClickListener { showData() }
    }

    private fun signUpUser() {
        val email = editTextEmail.text.toString().trim()
        val password = editTextPassword.text.toString().trim()
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập email và mật khẩu", Toast.LENGTH_SHORT).show()
            return
        }

        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Log.d(TAG, "Đăng ký thành công")
                    val user = auth.currentUser
                    saveUserData(user?.uid, email)
                } else {
                    Log.e(TAG, "Đăng ký thất bại: ${task.exception?.message}", task.exception)
                    Toast.makeText(this, "Đăng ký thất bại: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun signInUser() {
        val email = editTextEmail.text.toString().trim()
        val password = editTextPassword.text.toString().trim()

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập email và mật khẩu", Toast.LENGTH_SHORT).show()
            return
        }

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Log.d(TAG, "Đăng nhập thành công")
                    val user = auth.currentUser
                } else {
                    Log.e(TAG, "Đăng nhập thất bại: ${task.exception?.message}", task.exception)
                    Toast.makeText(this, "Đăng nhập thất bại: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }
    private fun saveUserData(userId: String?, email: String?) {
        if (userId == null || email == null) {
            Log.e(TAG, "Không thể lưu dữ liệu: userId hoặc email null")
            Toast.makeText(this, "Không thể lưu dữ liệu người dùng", Toast.LENGTH_SHORT).show()
            return
        }

        val user = User(email)

        database.child("users").child(userId).setValue(user)
            .addOnSuccessListener {
                Log.d(TAG, "Lưu dữ liệu người dùng thành công")
                Toast.makeText(this, "Lưu dữ liệu người dùng thành công", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Lỗi khi lưu dữ liệu người dùng: ${e.message}", e)
                Toast.makeText(this, "Lỗi khi lưu dữ liệu người dùng: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showData() {
        val userId = auth.currentUser?.uid
        if (userId == null) {
            Log.e(TAG, "Không thể hiển thị dữ liệu: Người dùng chưa đăng nhập")
            Toast.makeText(this, "Vui lòng đăng nhập để xem dữ liệu", Toast.LENGTH_SHORT).show()
            return
        }

        database.child("users").child(userId).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val user = snapshot.getValue(User::class.java)
                if (user != null) {
                    textViewData.text = "Email: ${user.email}"
                } else {
                    Log.w(TAG, "Không tìm thấy dữ liệu người dùng")
                    textViewData.text = "Không tìm thấy dữ liệu người dùng"
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Lỗi khi đọc dữ liệu: ${error.message}", error.toException())
                Toast.makeText(this@MainActivity, "Lỗi khi đọc dữ liệu: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
    data class User(val email: String? = null)

}