package com.example.btth04

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.saveable.Saver
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.btth04.ui.theme.BTTH04Theme

private lateinit var editTextUsername: EditText
private lateinit var editTextPassword: EditText
private lateinit var buttonSave: Button
private lateinit var buttonDelete: Button
private lateinit var buttonShow: Button

private lateinit var preferenceHelper: PreferenceHelper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preferenceHelper = PreferenceHelper(this)

        editTextUsername = findViewById<EditText>(R.id.editTextUsername)
        editTextPassword = findViewById(R.id.editTextPassword)
        buttonSave = findViewById<Button>(R.id.buttonSave)
        buttonDelete = findViewById(R.id.buttonDelete)
        buttonShow = findViewById(R.id.buttonShow)

        buttonSave.setOnClickListener {
            saveInfo()
        }
        buttonDelete.setOnClickListener {
            deleteInfo()
        }
        buttonShow.setOnClickListener {
            showInfo()
        }
    }

    private fun saveInfo() {
        val username = editTextUsername.text.toString()
        val password = editTextPassword.text.toString()
        if(username.isEmpty() && password.isEmpty()){
            Toast.makeText(this, "Nhap tai khoan va mat khau", Toast.LENGTH_SHORT).show()
        } else {
            preferenceHelper.saveInfo(username, password)
            Toast.makeText(this, "Luu thanh cong", Toast.LENGTH_SHORT).show()
        }
    }
    private fun deleteInfo() {
        preferenceHelper.deleteInfo()
        editTextUsername.text.clear()
        editTextPassword.text.clear()
    }
    private fun showInfo() {
        val username = preferenceHelper.getUsername()
        val password = preferenceHelper.getPassword()

        if (username != null && password != null) {
            Toast.makeText(this, "Username: $username, Password: $password", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "No info saved.", Toast.LENGTH_SHORT).show()
        }
    }

}


