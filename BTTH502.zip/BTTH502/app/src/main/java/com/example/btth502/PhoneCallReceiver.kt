package com.example.btth502

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.telephony.SmsManager
import android.util.Log

@Suppress("DEPRECATION")
class PhoneCallReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "PhoneCallReceiver"
        private var lastState = TelephonyManager.EXTRA_STATE_IDLE // Trạng thái cuộc gọi cuối cùng
        private var incomingNumber: String? = null // Số điện thoại của người gọi đến
    }

    override fun onReceive(context: Context, intent: Intent) {
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return // Tránh NullPointerException

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                Log.d(TAG, "Ringing: $incomingNumber")
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                // Kiểm tra xem có phải cuộc gọi bị nhỡ không (khi chuyển từ RINGING sang IDLE)
                if (lastState == TelephonyManager.EXTRA_STATE_RINGING) {
                    Log.d(TAG, "Missed call from: $incomingNumber")
                    incomingNumber?.let { sendSMS(context, it, "Xin lỗi, tôi đang bận. Tôi sẽ gọi lại sau.") }
                    incomingNumber = null // Reset để tránh gửi lại tin nhắn
                }
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                // Cuộc gọi đã được nhấc máy, reset incomingNumber để không gửi SMS
                incomingNumber = null
            }
        }

        lastState = state // Cập nhật trạng thái cuộc gọi cuối cùng
    }

    private fun sendSMS(context: Context, phoneNumber: String, message: String) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            Log.d(TAG, "SMS sent to: $phoneNumber")
        } catch (e: Exception) {
            Log.e(TAG, "SMS sending failed: ${e.message}")
            e.printStackTrace()
        }
    }
}